class AWSClient {
  constructor(region) {
    this.region = region;
  }
}

export default AWSClient;